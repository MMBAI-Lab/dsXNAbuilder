Use case of the dsXNAbuilder paper (Supplementary Table S4).
<system>_built.pdb: duplex as built by dsXNAbuilder (header records the input).
<system>_md_100ns.pdb: last frame of the 100-ns simulation, heavy atoms,
superposed on the built structure (inner base pairs).
